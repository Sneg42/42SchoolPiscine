int		index_in_str_base(char numb)
{
	char *base = "0123456789abcdef";
	int ind = 0;
	if (numb >= 'A' && numb <= 'Z')
		numb += 32;

	while (base[ind] != numb)
		ind++;
	return (ind);
}

int length_str(const char *str)
{
	int length = 0;
	while (str[length])
		length++;
	return length;
}

int calc_power(int power, int str_base)
{	
	if (power == 0)
		return 1;
	int numb = str_base;
	while (power-- > 1)
		numb *= str_base;
	return numb;
}

int ft_atoi_base(const char *str, int str_base)
{
	int numb = 0;
	int power;
	int pos = 1;

	if (*str == '-'){
		pos = -1;
		str++;
	}
	power = length_str(str) - 1;
	while (*str)
		numb += index_in_str_base(*str++) * calc_power(power--, str_base);
	return (numb * pos);
}
